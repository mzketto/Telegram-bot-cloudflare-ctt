let BOT_TOKEN;
let GROUP_ID;
let MAX_MESSAGES_PER_MINUTE;

let lastCleanupTime = 0;
const CLEANUP_INTERVAL = 24 * 60 * 60 * 1000; // 24 小时
let isInitialized = false;
const processedMessages = new Set();
const processedCallbacks = new Set();

// 安全增强：限制集合大小
const MAX_PROCESSED_MESSAGES = 5000;
const MAX_PROCESSED_CALLBACKS = 1000;

// 安全的表名白名单
const ALLOWED_TABLE_NAMES = new Set([
  'user_states', 
  'message_rates', 
  'chat_topic_mappings', 
  'settings'
]);

// 安全的设置键白名单
const ALLOWED_SETTINGS_KEYS = new Set([
  'verification_enabled', 
  'user_raw_enabled'
]);

const topicCreationLocks = new Map();

const settingsCache = new Map([
  ['verification_enabled', null],
  ['user_raw_enabled', null]
]);

class LRUCache {
  constructor(maxSize) {
    this.maxSize = maxSize;
    this.cache = new Map();
  }
  get(key) {
    if (typeof key !== 'string' && typeof key !== 'number') {
      return undefined;
    }
    const value = this.cache.get(key);
    if (value !== undefined) {
      this.cache.delete(key);
      this.cache.set(key, value);
    }
    return value;
  }
  set(key, value) {
    if (typeof key !== 'string' && typeof key !== 'number') {
      return;
    }
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    this.cache.set(key, value);
  }
  clear() {
    this.cache.clear();
  }
  
  // 新增：安全的大小检查方法
  isFull() {
    return this.cache.size >= this.maxSize;
  }
  
  // 新增：安全的键数量管理
  trimIfNeeded() {
    if (this.cache.size > this.maxSize * 0.9) {
      const keysToDelete = Math.floor(this.maxSize * 0.1);
      const iterator = this.cache.keys();
      for (let i = 0; i < keysToDelete; i++) {
        const key = iterator.next().value;
        if (key !== undefined) {
          this.cache.delete(key);
        }
      }
    }
  }
}

const userInfoCache = new LRUCache(1000);
const topicIdCache = new LRUCache(1000);
const userStateCache = new LRUCache(1000);
const messageRateCache = new LRUCache(1000);

// 安全增强：输入验证工具函数
class SecurityValidator {
  // 验证chat_id格式
  static isValidChatId(chatId) {
    return typeof chatId === 'string' && /^-?\d+$/.test(chatId) && chatId.length <= 20;
  }
  
  // 验证消息ID
  static isValidMessageId(messageId) {
    return typeof messageId === 'string' || typeof messageId === 'number';
  }
  
  // 验证回调查询数据
  static isValidCallbackData(data) {
    return typeof data === 'string' && data.length <= 200 && /^[a-zA-Z0-9_/-]+$/.test(data);
  }
  
  // 验证用户ID
  static isValidUserId(userId) {
    return typeof userId === 'string' || typeof userId === 'number';
  }
  
  // 验证话题ID
  static isValidTopicId(topicId) {
    return typeof topicId === 'string' || typeof topicId === 'number';
  }
  
  // 清理和转义文本
  static sanitizeText(text, maxLength = 4000) {
    if (typeof text !== 'string') return '';
    
    return text
      .replace(/[<>]/g, '') // 移除潜在的HTML标签
      .substring(0, maxLength) // 限制长度
      .trim();
  }
  
  // 验证表名（防止SQL注入）
  static isValidTableName(tableName) {
    return ALLOWED_TABLE_NAMES.has(tableName);
  }
  
  // 验证设置键
  static isValidSettingKey(key) {
    return ALLOWED_SETTINGS_KEYS.has(key);
  }
}

export default {
  async fetch(request, env) {
    BOT_TOKEN = env.BOT_TOKEN_ENV || null;
    GROUP_ID = env.GROUP_ID_ENV || null;
    MAX_MESSAGES_PER_MINUTE = env.MAX_MESSAGES_PER_MINUTE_ENV ? parseInt(env.MAX_MESSAGES_PER_MINUTE_ENV) : 40;

    if (!env.D1) {
      return new Response('Server configuration error: D1 database is not bound', { status: 500 });
    }

    if (!isInitialized) {
      try {
        await initialize(env.D1, request);
        isInitialized = true;
      } catch (error) {
        console.error('Initialization failed:', error.message);
        // 不阻止服务启动，但记录错误
      }
    }

    async function handleRequest(request) {
      if (!BOT_TOKEN || !GROUP_ID) {
        return new Response('Server configuration error: Missing required environment variables', { status: 500 });
      }

      try {
        const url = new URL(request.url);
        
        // 安全增强：检查路径长度
        if (url.pathname.length > 100) {
          return new Response('Bad Request', { status: 400 });
        }

        if (url.pathname === '/webhook') {
          try {
            const update = await request.json();
            // 安全增强：验证update结构
            if (!update || typeof update !== 'object') {
              return new Response('Bad Request', { status: 400 });
            }
            await handleUpdate(update);
            return new Response('OK');
          } catch (error) {
            console.error('Webhook processing error:', error.message);
            return new Response('Bad Request', { status: 400 });
          }
        } else if (url.pathname === '/registerWebhook') {
          return await registerWebhook(request);
        } else if (url.pathname === '/unRegisterWebhook') {
          return await unRegisterWebhook();
        } else if (url.pathname === '/checkTables') {
          await checkAndRepairTables(env.D1);
          return new Response('Database tables checked and repaired', { status: 200 });
        }
        return new Response('Not Found', { status: 404 });
      } catch (error) {
        console.error('Request handling error:', error.message);
        return new Response('Internal Server Error', { status: 500 });
      }
    }

    async function initialize(d1, request) {
      await Promise.all([
        checkAndRepairTables(d1),
        autoRegisterWebhook(request),
        checkBotPermissions(),
        cleanExpiredVerificationCodes(d1)
      ]);
    }

    async function autoRegisterWebhook(request) {
      try {
        const webhookUrl = `${new URL(request.url).origin}/webhook`;
        // 安全增强：验证URL格式
        if (!webhookUrl.startsWith('https://') || webhookUrl.length > 200) {
          throw new Error('Invalid webhook URL');
        }
        await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: webhookUrl }),
        });
      } catch (error) {
        console.error('Auto-register webhook failed:', error.message);
        // 不抛出错误，继续运行
      }
    }

    async function checkBotPermissions() {
      try {
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/getChat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chat_id: GROUP_ID })
        });
        const data = await response.json();
        if (!data.ok) {
          throw new Error(`Failed to access group: ${data.description}`);
        }

        const memberResponse = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/getChatMember`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: GROUP_ID,
            user_id: (await getBotId())
          })
        });
        const memberData = await memberResponse.json();
        if (!memberData.ok) {
          throw new Error(`Failed to get bot member status: ${memberData.description}`);
        }
      } catch (error) {
        console.error('Bot permission check failed:', error.message);
        // 不阻止服务运行
      }
    }

    async function getBotId() {
      try {
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/getMe`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({})
        });
        const data = await response.json();
        if (!data.ok) throw new Error(`Failed to get bot ID: ${data.description}`);
        return data.result.id;
      } catch (error) {
        console.error('Get bot ID failed:', error.message);
        throw error;
      }
    }

    async function checkAndRepairTables(d1) {
      const expectedTables = {
        user_states: {
          columns: {
            chat_id: 'TEXT PRIMARY KEY',
            is_blocked: 'BOOLEAN DEFAULT FALSE',
            is_verified: 'BOOLEAN DEFAULT FALSE',
            verified_expiry: 'INTEGER',
            verification_code: 'TEXT',
            code_expiry: 'INTEGER',
            last_verification_message_id: 'TEXT',
            is_first_verification: 'BOOLEAN DEFAULT TRUE',
            is_rate_limited: 'BOOLEAN DEFAULT FALSE',
            is_verifying: 'BOOLEAN DEFAULT FALSE'
          }
        },
        message_rates: {
          columns: {
            chat_id: 'TEXT PRIMARY KEY',
            message_count: 'INTEGER DEFAULT 0',
            window_start: 'INTEGER',
            start_count: 'INTEGER DEFAULT 0',
            start_window_start: 'INTEGER'
          }
        },
        chat_topic_mappings: {
          columns: {
            chat_id: 'TEXT PRIMARY KEY',
            topic_id: 'TEXT NOT NULL'
          }
        },
        settings: {
          columns: {
            key: 'TEXT PRIMARY KEY',
            value: 'TEXT'
          }
        }
      };

      for (const [tableName, structure] of Object.entries(expectedTables)) {
        // 安全增强：验证表名
        if (!SecurityValidator.isValidTableName(tableName)) {
          console.warn(`Invalid table name attempted: ${tableName}`);
          continue;
        }

        try {
          const tableInfo = await d1.prepare(
            `SELECT sql FROM sqlite_master WHERE type='table' AND name=?`
          ).bind(tableName).first();

          if (!tableInfo) {
            await createTable(d1, tableName, structure);
            continue;
          }

          const columnsResult = await d1.prepare(
            `PRAGMA table_info(${tableName})`
          ).all();
          
          const currentColumns = new Map(
            columnsResult.results.map(col => [col.name, {
              type: col.type,
              notnull: col.notnull,
              dflt_value: col.dflt_value
            }])
          );

          for (const [colName, colDef] of Object.entries(structure.columns)) {
            if (!currentColumns.has(colName)) {
              // 安全增强：验证列名格式
              if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(colName)) {
                console.warn(`Invalid column name: ${colName}`);
                continue;
              }
              const columnParts = colDef.split(' ');
              const addColumnSQL = `ALTER TABLE ${tableName} ADD COLUMN ${colName} ${columnParts.slice(1).join(' ')}`;
              await d1.exec(addColumnSQL);
            }
          }

          if (tableName === 'settings') {
            await d1.exec('CREATE INDEX IF NOT EXISTS idx_settings_key ON settings (key)');
          }
        } catch (error) {
          console.error(`Error checking table ${tableName}:`, error.message);
          // 继续处理其他表
        }
      }

      try {
        await Promise.all([
          d1.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)')
            .bind('verification_enabled', 'true').run(),
          d1.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)')
            .bind('user_raw_enabled', 'true').run()
        ]);

        settingsCache.set('verification_enabled', (await getSetting('verification_enabled', d1)) === 'true');
        settingsCache.set('user_raw_enabled', (await getSetting('user_raw_enabled', d1)) === 'true');
      } catch (error) {
        console.error('Settings initialization error:', error.message);
      }
    }

    async function createTable(d1, tableName, structure) {
      const columnsDef = Object.entries(structure.columns)
        .map(([name, def]) => {
          // 安全增强：验证列名和定义
          if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name)) {
            throw new Error(`Invalid column name: ${name}`);
          }
          return `${name} ${def}`;
        })
        .join(', ');
      const createSQL = `CREATE TABLE ${tableName} (${columnsDef})`;
      await d1.exec(createSQL);
    }

    async function cleanExpiredVerificationCodes(d1) {
      const now = Date.now();
      if (now - lastCleanupTime < CLEANUP_INTERVAL) {
        return;
      }

      try {
        const nowSeconds = Math.floor(now / 1000);
        const expiredCodes = await d1.prepare(
          'SELECT chat_id FROM user_states WHERE code_expiry IS NOT NULL AND code_expiry < ?'
        ).bind(nowSeconds).all();

        if (expiredCodes.results.length > 0) {
          await d1.batch(
            expiredCodes.results.map(({ chat_id }) =>
              d1.prepare(
                'UPDATE user_states SET verification_code = NULL, code_expiry = NULL, is_verifying = FALSE WHERE chat_id = ?'
              ).bind(chat_id)
            )
          );
        }
        lastCleanupTime = now;
      } catch (error) {
        console.error('Cleanup error:', error.message);
        // 不抛出错误，继续运行
      }
    }

    async function handleUpdate(update) {
      try {
        if (update.message) {
          const messageId = update.message.message_id?.toString();
          const chatId = update.message.chat?.id?.toString();
          
          // 安全增强：验证messageId和chatId
          if (!SecurityValidator.isValidMessageId(messageId) || !SecurityValidator.isValidChatId(chatId)) {
            return;
          }
          
          const messageKey = `${chatId}:${messageId}`;
          
          if (processedMessages.has(messageKey)) {
            return;
          }
          processedMessages.add(messageKey);
          
          // 安全增强：限制集合大小
          if (processedMessages.size > MAX_PROCESSED_MESSAGES) {
            processedMessages.clear();
          }

          await onMessage(update.message);
        } else if (update.callback_query) {
          await onCallbackQuery(update.callback_query);
        }
      } catch (error) {
        console.error('Update handling error:', error.message);
        // 不抛出错误，避免中断其他更新处理
      }
    }

    async function onMessage(message) {
      try {
        const chatId = message.chat.id.toString();
        const text = message.text || '';
        const messageId = message.message_id;

        // 安全增强：验证chatId
        if (!SecurityValidator.isValidChatId(chatId)) {
          return;
        }

        if (chatId === GROUP_ID) {
          const topicId = message.message_thread_id;
          if (topicId) {
            const privateChatId = await getPrivateChatId(topicId);
            if (privateChatId && text === '/admin') {
              await sendAdminPanel(chatId, topicId, privateChatId, messageId);
              return;
            }
            if (privateChatId && text.startsWith('/reset_user')) {
              await handleResetUser(chatId, topicId, text);
              return;
            }
            if (privateChatId) {
              await forwardMessageToPrivateChat(privateChatId, message);
            }
          }
          return;
        }

        // 安全增强：检查用户状态
        let userState = userStateCache.get(chatId);
        if (userState === undefined) {
          userState = await env.D1.prepare('SELECT is_blocked, is_first_verification, is_verified, verified_expiry, is_verifying FROM user_states WHERE chat_id = ?')
            .bind(chatId)
            .first();
          if (!userState) {
            userState = { is_blocked: false, is_first_verification: true, is_verified: false, verified_expiry: null, is_verifying: false };
            await env.D1.prepare('INSERT INTO user_states (chat_id, is_blocked, is_first_verification, is_verified, is_verifying) VALUES (?, ?, ?, ?, ?)')
              .bind(chatId, false, true, false, false)
              .run();
          }
          userStateCache.set(chatId, userState);
        }

        if (userState.is_blocked) {
          await sendMessageToUser(chatId, "您已被拉黑，无法发送消息。请联系管理员解除拉黑。");
          return;
        }

        const verificationEnabled = (await getSetting('verification_enabled', env.D1)) === 'true';

        if (!verificationEnabled) {
          // 验证码关闭时，所有用户都可以直接发送消息
        } else {
          const nowSeconds = Math.floor(Date.now() / 1000);
          const isVerified = userState.is_verified && userState.verified_expiry && nowSeconds < userState.verified_expiry;
          const isFirstVerification = userState.is_first_verification;
          const isRateLimited = await checkMessageRate(chatId);
          const isVerifying = userState.is_verifying || false;

          if (!isVerified || (isRateLimited && !isFirstVerification)) {
            if (isVerifying) {
              // 检查验证码是否已过期
              const storedCode = await env.D1.prepare('SELECT verification_code, code_expiry FROM user_states WHERE chat_id = ?')
                .bind(chatId)
                .first();
              
              const nowSeconds2 = Math.floor(Date.now() / 1000);
              const isCodeExpired = !storedCode?.verification_code || !storedCode?.code_expiry || nowSeconds2 > storedCode.code_expiry;
              
              if (isCodeExpired) {
                // 如果验证码已过期，重新发送验证码
                await sendMessageToUser(chatId, '验证码已过期，正在为您发送新的验证码...');
                await env.D1.prepare('UPDATE user_states SET verification_code = NULL, code_expiry = NULL, is_verifying = FALSE WHERE chat_id = ?')
                  .bind(chatId)
                  .run();
                userStateCache.set(chatId, { ...userState, verification_code: null, code_expiry: null, is_verifying: false });
                
                // 删除旧的验证消息（如果存在）
                try {
                  const lastVerification = await env.D1.prepare('SELECT last_verification_message_id FROM user_states WHERE chat_id = ?')
                    .bind(chatId)
                    .first();
                  
                  if (lastVerification?.last_verification_message_id) {
                    try {
                      await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          chat_id: chatId,
                          message_id: lastVerification.last_verification_message_id
                        })
                      });
                    } catch (deleteError) {
                      console.log(`删除旧验证消息失败: ${deleteError.message}`);
                    }
                    
                    await env.D1.prepare('UPDATE user_states SET last_verification_message_id = NULL WHERE chat_id = ?')
                      .bind(chatId)
                      .run();
                  }
                } catch (error) {
                  console.log(`查询旧验证消息失败: ${error.message}`);
                }
                
                // 立即发送新的验证码
                try {
                  await handleVerification(chatId, 0);
                } catch (verificationError) {
                  console.error(`发送新验证码失败: ${verificationError.message}`);
                  // 如果发送验证码失败，则再次尝试
                  setTimeout(async () => {
                    try {
                      await handleVerification(chatId, 0);
                    } catch (retryError) {
                      console.error(`重试发送验证码仍失败: ${retryError.message}`);
                      await sendMessageToUser(chatId, '发送验证码失败，请发送任意消息重试');
                    }
                  }, 1000);
                }
                return;
              } else {
                await sendMessageToUser(chatId, `请完成验证后发送消息"${text || '您的具体信息'}"。`);
              }
              return;
            }
            await sendMessageToUser(chatId, `请完成验证后发送消息"${text || '您的具体信息'}"。`);
            await handleVerification(chatId, messageId);
            return;
          }
        }

        // 安全增强：验证文本长度
        const sanitizedText = SecurityValidator.sanitizeText(text);
        if (text && text.length > 4000) {
          await sendMessageToUser(chatId, "消息过长，请控制在4000字符以内。");
          return;
        }

        if (sanitizedText === '/start') {
          if (await checkStartCommandRate(chatId)) {
            await sendMessageToUser(chatId, "您发送 /start 命令过于频繁，请稍后再试！");
            return;
          }

          const successMessage = await getVerificationSuccessMessage();
          await sendMessageToUser(chatId, `${successMessage}\n你好，欢迎使用私聊机器人，现在发送信息吧！`);
          const userInfo = await getUserInfo(chatId);
          await ensureUserTopic(chatId, userInfo);
          return;
        }

        const userInfo = await getUserInfo(chatId);
        if (!userInfo) {
          await sendMessageToUser(chatId, "无法获取用户信息，请稍后再试或联系管理员。");
          return;
        }

        let topicId = await ensureUserTopic(chatId, userInfo);
        if (!topicId) {
          await sendMessageToUser(chatId, "无法创建话题，请稍后再试或联系管理员。");
          return;
        }

        const isTopicValid = await validateTopic(topicId);
        if (!isTopicValid) {
          await env.D1.prepare('DELETE FROM chat_topic_mappings WHERE chat_id = ?').bind(chatId).run();
          topicIdCache.set(chatId, undefined);
          topicId = await ensureUserTopic(chatId, userInfo);
          if (!topicId) {
            await sendMessageToUser(chatId, "无法重新创建话题，请稍后再试或联系管理员。");
            return;
          }
        }

        const userName = userInfo.username || `User_${chatId}`;
        const nickname = userInfo.nickname || userName;

        if (sanitizedText) {
          const formattedMessage = `${SecurityValidator.sanitizeText(nickname, 100)}:\n${sanitizedText}`;
          await sendMessageToTopic(topicId, formattedMessage);
        } else {
          await copyMessageToTopic(topicId, message);
        }
      } catch (error) {
        console.error('Message handling error:', error.message);
        // 不抛出错误，继续处理其他消息
      }
    }

    async function validateTopic(topicId) {
      try {
        // 安全增强：验证topicId
        if (!SecurityValidator.isValidTopicId(topicId)) {
          return false;
        }

        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: GROUP_ID,
            message_thread_id: topicId,
            text: "您有新消息！",
            disable_notification: true
          })
        });
        const data = await response.json();
        if (data.ok) {
          await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: GROUP_ID,
              message_id: data.result.message_id
            })
          });
          return true;
        }
        return false;
      } catch (error) {
        console.error('Topic validation error:', error.message);
        return false;
      }
    }

    async function ensureUserTopic(chatId, userInfo) {
      // 安全增强：验证输入参数
      if (!SecurityValidator.isValidChatId(chatId) || !userInfo) {
        return null;
      }

      let lock = topicCreationLocks.get(chatId);
      if (!lock) {
        lock = Promise.resolve();
        topicCreationLocks.set(chatId, lock);
      }

      try {
        await lock;

        let topicId = await getExistingTopicId(chatId);
        if (topicId) {
          return topicId;
        }

        // 安全增强：防止重复创建
        const newLock = (async () => {
          const userName = SecurityValidator.sanitizeText(userInfo.username || `User_${chatId}`, 50);
          const nickname = SecurityValidator.sanitizeText(userInfo.nickname || userName, 50);
          topicId = await createForumTopic(nickname, userName, nickname, userInfo.id || chatId);
          await saveTopicId(chatId, topicId);
          return topicId;
        })();

        topicCreationLocks.set(chatId, newLock);
        return await newLock;
      } catch (error) {
        console.error('Ensure user topic error:', error.message);
        return null;
      } finally {
        // 安全增强：安全清理锁
        if (topicCreationLocks.get(chatId) === lock) {
          topicCreationLocks.delete(chatId);
        }
      }
    }

    async function handleResetUser(chatId, topicId, text) {
      try {
        // 安全增强：验证参数
        if (!SecurityValidator.isValidChatId(chatId) || !SecurityValidator.isValidTopicId(topicId)) {
          return;
        }

        const senderId = chatId;
        const isAdmin = await checkIfAdmin(senderId);
        if (!isAdmin) {
          await sendMessageToTopic(topicId, '只有管理员可以使用此功能。');
          return;
        }

        const parts = text.split(' ');
        if (parts.length !== 2) {
          await sendMessageToTopic(topicId, '用法：/reset_user <chat_id>');
          return;
        }

        const targetChatId = parts[1];
        // 安全增强：验证目标chatId
        if (!SecurityValidator.isValidChatId(targetChatId)) {
          await sendMessageToTopic(topicId, '无效的用户ID。');
          return;
        }

        await env.D1.batch([
          env.D1.prepare('DELETE FROM user_states WHERE chat_id = ?').bind(targetChatId),
          env.D1.prepare('DELETE FROM message_rates WHERE chat_id = ?').bind(targetChatId),
          env.D1.prepare('DELETE FROM chat_topic_mappings WHERE chat_id = ?').bind(targetChatId)
        ]);
        userStateCache.set(targetChatId, undefined);
        messageRateCache.set(targetChatId, undefined);
        topicIdCache.set(targetChatId, undefined);
        await sendMessageToTopic(topicId, `用户 ${targetChatId} 的状态已重置。`);
      } catch (error) {
        console.error('Reset user error:', error.message);
        await sendMessageToTopic(topicId, '重置用户状态失败。');
      }
    }

    async function sendAdminPanel(chatId, topicId, privateChatId, messageId) {
      try {
        // 安全增强：验证参数
        if (!SecurityValidator.isValidChatId(chatId) || !SecurityValidator.isValidTopicId(topicId) || !SecurityValidator.isValidChatId(privateChatId)) {
          return;
        }

        const verificationEnabled = (await getSetting('verification_enabled', env.D1)) === 'true';
        const userRawEnabled = (await getSetting('user_raw_enabled', env.D1)) === 'true';

        const buttons = [
          [
            { text: '拉黑用户', callback_data: `block_${privateChatId}` },
            { text: '解除拉黑', callback_data: `unblock_${privateChatId}` }
          ],
          [
            { text: verificationEnabled ? '关闭验证码' : '开启验证码', callback_data: `toggle_verification_${privateChatId}` },
            { text: '查询黑名单', callback_data: `check_blocklist_${privateChatId}` }
          ],
          [
            { text: userRawEnabled ? '关闭用户Raw' : '开启用户Raw', callback_data: `toggle_user_raw_${privateChatId}` },
            { text: 'GitHub项目', url: 'https://github.com/mzketto/Telegram-bot-cloudflare-ctt' }
          ],
          [
            { text: '删除用户', callback_data: `delete_user_${privateChatId}` }
          ]
        ];

        const adminMessage = '管理员面板：请选择操作';
        await Promise.all([
          fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: chatId,
              message_thread_id: topicId,
              text: adminMessage,
              reply_markup: { inline_keyboard: buttons }
            })
          }),
          fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: chatId,
              message_id: messageId
            })
          })
        ]);
      } catch (error) {
        console.error('Send admin panel error:', error.message);
      }
    }

    async function getVerificationSuccessMessage() {
      try {
        const userRawEnabled = (await getSetting('user_raw_enabled', env.D1)) === 'true';
        if (!userRawEnabled) return '验证成功！您现在可以与我聊天。';

        // 安全增强：添加超时和错误处理
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        try {
          const response = await fetch('https://raw.githubusercontent.com/mzketto/Telegram-bot-cloudflare-ctt/blob/main/CFTeleTrans/start.md', {
            signal: controller.signal
          });
          clearTimeout(timeoutId);
          
          if (!response.ok) return '验证成功！您现在可以与我聊天。';
          const message = await response.text();
          return SecurityValidator.sanitizeText(message.trim()) || '验证成功！您现在可以与我聊天。';
        } catch (error) {
          clearTimeout(timeoutId);
          return '验证成功！您现在可以与我聊天。';
        }
      } catch (error) {
        console.error('Get verification success message error:', error.message);
        return '验证成功！您现在可以与我聊天。';
      }
    }

    async function getNotificationContent() {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        try {
          const response = await fetch('https://raw.githubusercontent.com/mzketto/Telegram-bot-cloudflare-ctt/blob/main/CFTeleTrans/notification.md', {
            signal: controller.signal
          });
          clearTimeout(timeoutId);
          
          if (!response.ok) return '';
          const content = await response.text();
          return SecurityValidator.sanitizeText(content.trim());
        } catch (error) {
          clearTimeout(timeoutId);
          return '';
        }
      } catch (error) {
        console.error('Get notification content error:', error.message);
        return '';
      }
    }

    async function checkStartCommandRate(chatId) {
      try {
        if (!SecurityValidator.isValidChatId(chatId)) {
          return false;
        }

        const now = Date.now();
        const window = 5 * 60 * 1000;
        const maxStartsPerWindow = 1;

        let data = messageRateCache.get(chatId);
        if (data === undefined) {
          data = await env.D1.prepare('SELECT start_count, start_window_start FROM message_rates WHERE chat_id = ?')
            .bind(chatId)
            .first();
          if (!data) {
            data = { start_count: 0, start_window_start: now };
            await env.D1.prepare('INSERT INTO message_rates (chat_id, start_count, start_window_start) VALUES (?, ?, ?)')
              .bind(chatId, data.start_count, data.start_window_start)
              .run();
          }
          messageRateCache.set(chatId, data);
        }

        if (now - data.start_window_start > window) {
          data.start_count = 1;
          data.start_window_start = now;
          await env.D1.prepare('UPDATE message_rates SET start_count = ?, start_window_start = ? WHERE chat_id = ?')
            .bind(data.start_count, data.start_window_start, chatId)
            .run();
        } else {
          data.start_count += 1;
          await env.D1.prepare('UPDATE message_rates SET start_count = ? WHERE chat_id = ?')
            .bind(data.start_count, chatId)
            .run();
        }

        messageRateCache.set(chatId, data);
        return data.start_count > maxStartsPerWindow;
      } catch (error) {
        console.error('Check start command rate error:', error.message);
        return false;
      }
    }

    async function checkMessageRate(chatId) {
      try {
        if (!SecurityValidator.isValidChatId(chatId)) {
          return false;
        }

        const now = Date.now();
        const window = 60 * 1000;

        let data = messageRateCache.get(chatId);
        if (data === undefined) {
          data = await env.D1.prepare('SELECT message_count, window_start FROM message_rates WHERE chat_id = ?')
            .bind(chatId)
            .first();
          if (!data) {
            data = { message_count: 0, window_start: now };
            await env.D1.prepare('INSERT INTO message_rates (chat_id, message_count, window_start) VALUES (?, ?, ?)')
              .bind(chatId, data.message_count, data.window_start)
              .run();
          }
          messageRateCache.set(chatId, data);
        }

        if (now - data.window_start > window) {
          data.message_count = 1;
          data.window_start = now;
        } else {
          data.message_count += 1;
        }

        messageRateCache.set(chatId, data);
        await env.D1.prepare('UPDATE message_rates SET message_count = ?, window_start = ? WHERE chat_id = ?')
          .bind(data.message_count, data.window_start, chatId)
          .run();
        return data.message_count > MAX_MESSAGES_PER_MINUTE;
      } catch (error) {
        console.error('Check message rate error:', error.message);
        return false;
      }
    }

    async function getSetting(key, d1) {
      try {
        if (!SecurityValidator.isValidSettingKey(key)) {
          console.warn(`Invalid setting key attempted: ${key}`);
          return null;
        }

        const result = await d1.prepare('SELECT value FROM settings WHERE key = ?')
          .bind(key)
          .first();
        return result?.value || null;
      } catch (error) {
        console.error('Get setting error:', error.message);
        return null;
      }
    }

    async function setSetting(key, value) {
      try {
        if (!SecurityValidator.isValidSettingKey(key)) {
          throw new Error(`Invalid setting key: ${key}`);
        }

        // 安全增强：验证value类型和长度
        if (typeof value !== 'string' || value.length > 100) {
          throw new Error('Invalid setting value');
        }

        await env.D1.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)')
          .bind(key, value)
          .run();
          
        if (key === 'verification_enabled') {
          settingsCache.set('verification_enabled', value === 'true');
          if (value === 'false') {
            const nowSeconds = Math.floor(Date.now() / 1000);
            const verifiedExpiry = nowSeconds + 3600 * 24;
            await env.D1.prepare('UPDATE user_states SET is_verified = ?, verified_expiry = ?, is_verifying = ?, verification_code = NULL, code_expiry = NULL, is_first_verification = ? WHERE chat_id NOT IN (SELECT chat_id FROM user_states WHERE is_blocked = TRUE)')
              .bind(true, verifiedExpiry, false, false)
              .run();
            userStateCache.clear();
          }
        } else if (key === 'user_raw_enabled') {
          settingsCache.set('user_raw_enabled', value === 'true');
        }
      } catch (error) {
        console.error('Set setting error:', error.message);
        throw error;
      }
    }

    async function onCallbackQuery(callbackQuery) {
      try {
        const chatId = callbackQuery.message.chat.id.toString();
        const topicId = callbackQuery.message.message_thread_id;
        const data = callbackQuery.data;
        const messageId = callbackQuery.message.message_id;
        
        // 安全增强：验证callback_data
        if (!SecurityValidator.isValidCallbackData(data)) {
          return;
        }

        const callbackKey = `${chatId}:${callbackQuery.id}`;

        if (processedCallbacks.has(callbackKey)) {
          return;
        }
        processedCallbacks.add(callbackKey);
        
        // 安全增强：限制回调集合大小
        if (processedCallbacks.size > MAX_PROCESSED_CALLBACKS) {
          processedCallbacks.clear();
        }

        const parts = data.split('_');
        let action;
        let privateChatId;

        if (data.startsWith('verify_')) {
          action = 'verify';
          privateChatId = parts[1];
        } else if (data.startsWith('toggle_verification_')) {
          action = 'toggle_verification';
          privateChatId = parts.slice(2).join('_');
        } else if (data.startsWith('toggle_user_raw_')) {
          action = 'toggle_user_raw';
          privateChatId = parts.slice(3).join('_');
        } else if (data.startsWith('check_blocklist_')) {
          action = 'check_blocklist';
          privateChatId = parts.slice(2).join('_');
        } else if (data.startsWith('block_')) {
          action = 'block';
          privateChatId = parts[1];
        } else if (data.startsWith('unblock_')) {
          action = 'unblock';
          privateChatId = parts[1];
        } else if (data.startsWith('delete_user_')) {
          action = 'delete_user';
          privateChatId = parts[2];
        } else {
          action = data;
          privateChatId = '';
        }

        // 安全增强：验证privateChatId
        if (privateChatId && !SecurityValidator.isValidChatId(privateChatId)) {
          return;
        }

        if (action === 'verify') {
          const [, userChatId, selectedAnswer, result] = data.split('_');
          if (userChatId !== chatId) {
            return;
          }

          let verificationState = userStateCache.get(chatId);
          if (verificationState === undefined) {
            verificationState = await env.D1.prepare('SELECT verification_code, code_expiry, is_verifying FROM user_states WHERE chat_id = ?')
              .bind(chatId)
              .first();
            if (!verificationState) {
              verificationState = { verification_code: null, code_expiry: null, is_verifying: false };
            }
            userStateCache.set(chatId, verificationState);
          }

          const storedCode = verificationState.verification_code;
          const codeExpiry = verificationState.code_expiry;
          const nowSeconds = Math.floor(Date.now() / 1000);

          if (!storedCode || (codeExpiry && nowSeconds > codeExpiry)) {
            await sendMessageToUser(chatId, '验证码已过期，正在为您发送新的验证码...');
            await env.D1.prepare('UPDATE user_states SET verification_code = NULL, code_expiry = NULL, is_verifying = FALSE WHERE chat_id = ?')
              .bind(chatId)
              .run();
            userStateCache.set(chatId, { ...verificationState, verification_code: null, code_expiry: null, is_verifying: false });
            
            // 删除旧的验证消息
            try {
              await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  chat_id: chatId,
                  message_id: messageId
                })
              });
            } catch (error) {
              console.log(`删除过期验证按钮失败: ${error.message}`);
            }
            
            // 立即发送新的验证码
            try {
              await handleVerification(chatId, 0);
            } catch (verificationError) {
              console.error(`发送新验证码失败: ${verificationError.message}`);
              setTimeout(async () => {
                try {
                  await handleVerification(chatId, 0);
                } catch (retryError) {
                  console.error(`重试发送验证码仍失败: ${retryError.message}`);
                  await sendMessageToUser(chatId, '发送验证码失败，请发送任意消息重试');
                }
              }, 1000);
            }
            return;
          }

          if (result === 'correct') {
            const verifiedExpiry = nowSeconds + 3600 * 24;
            await env.D1.prepare('UPDATE user_states SET is_verified = ?, verified_expiry = ?, verification_code = NULL, code_expiry = NULL, last_verification_message_id = NULL, is_first_verification = ?, is_verifying = ? WHERE chat_id = ?')
              .bind(true, verifiedExpiry, false, false, chatId)
              .run();
            verificationState = await env.D1.prepare('SELECT is_verified, verified_expiry, verification_code, code_expiry, last_verification_message_id, is_first_verification, is_verifying FROM user_states WHERE chat_id = ?')
              .bind(chatId)
              .first();
            userStateCache.set(chatId, verificationState);

            let rateData = await env.D1.prepare('SELECT message_count, window_start FROM message_rates WHERE chat_id = ?')
              .bind(chatId)
              .first() || { message_count: 0, window_start: nowSeconds * 1000 };
            rateData.message_count = 0;
            rateData.window_start = nowSeconds * 1000;
            messageRateCache.set(chatId, rateData);
            await env.D1.prepare('UPDATE message_rates SET message_count = ?, window_start = ? WHERE chat_id = ?')
              .bind(0, nowSeconds * 1000, chatId)
              .run();

            const successMessage = await getVerificationSuccessMessage();
            await sendMessageToUser(chatId, `${successMessage}\n你好，欢迎使用私聊机器人！现在可以发送消息了。`);
            const userInfo = await getUserInfo(chatId);
            await ensureUserTopic(chatId, userInfo);
          } else {
            await sendMessageToUser(chatId, '验证失败，请重新尝试。');
            await handleVerification(chatId, messageId);
          }

          await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: chatId,
              message_id: messageId
            })
          });
        } else {
          const senderId = callbackQuery.from.id.toString();
          const isAdmin = await checkIfAdmin(senderId);
          if (!isAdmin) {
            await sendMessageToTopic(topicId, '只有管理员可以使用此功能。');
            await sendAdminPanel(chatId, topicId, privateChatId, messageId);
            return;
          }

          if (action === 'block') {
            // 安全增强：验证privateChatId
            if (!SecurityValidator.isValidChatId(privateChatId)) {
              await sendMessageToTopic(topicId, '无效的用户ID。');
              return;
            }

            let state = userStateCache.get(privateChatId);
            if (state === undefined) {
              state = await env.D1.prepare('SELECT is_blocked FROM user_states WHERE chat_id = ?')
                .bind(privateChatId)
                .first() || { is_blocked: false };
            }
            state.is_blocked = true;
            userStateCache.set(privateChatId, state);
            await env.D1.prepare('INSERT OR REPLACE INTO user_states (chat_id, is_blocked) VALUES (?, ?)')
              .bind(privateChatId, true)
              .run();
            await sendMessageToTopic(topicId, `用户 ${privateChatId} 已被拉黑，消息将不再转发。`);
          } else if (action === 'unblock') {
            // 安全增强：验证privateChatId
            if (!SecurityValidator.isValidChatId(privateChatId)) {
              await sendMessageToTopic(topicId, '无效的用户ID。');
              return;
            }

            let state = userStateCache.get(privateChatId);
            if (state === undefined) {
              state = await env.D1.prepare('SELECT is_blocked, is_first_verification FROM user_states WHERE chat_id = ?')
                .bind(privateChatId)
                .first() || { is_blocked: false, is_first_verification: true };
            }
            state.is_blocked = false;
            state.is_first_verification = true;
            userStateCache.set(privateChatId, state);
            await env.D1.prepare('INSERT OR REPLACE INTO user_states (chat_id, is_blocked, is_first_verification) VALUES (?, ?, ?)')
              .bind(privateChatId, false, true)
              .run();
            await sendMessageToTopic(topicId, `用户 ${privateChatId} 已解除拉黑，消息将继续转发。`);
          } else if (action === 'toggle_verification') {
            const currentState = (await getSetting('verification_enabled', env.D1)) === 'true';
            const newState = !currentState;
            await setSetting('verification_enabled', newState.toString());
            await sendMessageToTopic(topicId, `验证码功能已${newState ? '开启' : '关闭'}。`);
          } else if (action === 'check_blocklist') {
            const blockedUsers = await env.D1.prepare('SELECT chat_id FROM user_states WHERE is_blocked = ?')
              .bind(true)
              .all();
            const blockList = blockedUsers.results.length > 0 
              ? blockedUsers.results.map(row => SecurityValidator.sanitizeText(row.chat_id)).join('\n')
              : '当前没有被拉黑的用户。';
            await sendMessageToTopic(topicId, `黑名单列表：\n${blockList}`);
          } else if (action === 'toggle_user_raw') {
            const currentState = (await getSetting('user_raw_enabled', env.D1)) === 'true';
            const newState = !currentState;
            await setSetting('user_raw_enabled', newState.toString());
            await sendMessageToTopic(topicId, `用户端 Raw 链接已${newState ? '开启' : '关闭'}。`);
          } else if (action === 'delete_user') {
            // 安全增强：验证privateChatId
            if (!SecurityValidator.isValidChatId(privateChatId)) {
              await sendMessageToTopic(topicId, '无效的用户ID。');
              return;
            }

            userStateCache.set(privateChatId, undefined);
            messageRateCache.set(privateChatId, undefined);
            topicIdCache.set(privateChatId, undefined);
            await env.D1.batch([
              env.D1.prepare('DELETE FROM user_states WHERE chat_id = ?').bind(privateChatId),
              env.D1.prepare('DELETE FROM message_rates WHERE chat_id = ?').bind(privateChatId),
              env.D1.prepare('DELETE FROM chat_topic_mappings WHERE chat_id = ?').bind(privateChatId)
            ]);
            await sendMessageToTopic(topicId, `用户 ${privateChatId} 的状态、消息记录和话题映射已删除，用户需重新发起会话。`);
          } else {
            await sendMessageToTopic(topicId, `未知操作：${SecurityValidator.sanitizeText(action, 50)}`);
          }

          await sendAdminPanel(chatId, topicId, privateChatId, messageId);
        }

        await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callback_query_id: callbackQuery.id
          })
        });
      } catch (error) {
        console.error('Callback query handling error:', error.message);
        // 不抛出错误，继续处理其他回调
      }
    }

    async function handleVerification(chatId, messageId) {
      try {
        // 安全增强：验证参数
        if (!SecurityValidator.isValidChatId(chatId)) {
          throw new Error('Invalid chat ID');
        }

        let userState = userStateCache.get(chatId);
        if (userState === undefined) {
          userState = await env.D1.prepare('SELECT is_blocked, is_first_verification, is_verified, verified_expiry, is_verifying FROM user_states WHERE chat_id = ?')
            .bind(chatId)
            .first();
          if (!userState) {
            userState = { is_blocked: false, is_first_verification: true, is_verified: false, verified_expiry: null, is_verifying: false };
          }
          userStateCache.set(chatId, userState);
        }

        userState.verification_code = null;
        userState.code_expiry = null;
        userState.is_verifying = true;
        userStateCache.set(chatId, userState);
        await env.D1.prepare('UPDATE user_states SET verification_code = NULL, code_expiry = NULL, is_verifying = ? WHERE chat_id = ?')
          .bind(true, chatId)
          .run();

        const lastVerification = userState.last_verification_message_id || (await env.D1.prepare('SELECT last_verification_message_id FROM user_states WHERE chat_id = ?')
          .bind(chatId)
          .first())?.last_verification_message_id;

        if (lastVerification) {
          try {
            await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/deleteMessage`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: chatId,
                message_id: lastVerification
              })
            });
          } catch (deleteError) {
            console.log(`删除上一条验证消息失败: ${deleteError.message}`);
          }
          
          userState.last_verification_message_id = null;
          userStateCache.set(chatId, userState);
          await env.D1.prepare('UPDATE user_states SET last_verification_message_id = NULL WHERE chat_id = ?')
            .bind(chatId)
            .run();
        }

        // 确保发送验证码
        await sendVerification(chatId);
      } catch (error) {
        console.error(`处理验证过程失败: ${error.message}`);
        // 重置用户状态以防卡住
        try {
          await env.D1.prepare('UPDATE user_states SET is_verifying = FALSE WHERE chat_id = ?')
            .bind(chatId)
            .run();
          let currentState = userStateCache.get(chatId);
          if (currentState) {
            currentState.is_verifying = false;
            userStateCache.set(chatId, currentState);
          }
        } catch (resetError) {
          console.error(`重置用户验证状态失败: ${resetError.message}`);
        }
        throw error;
      }
    }

    async function sendVerification(chatId) {
      try {
        // 安全增强：验证chatId
        if (!SecurityValidator.isValidChatId(chatId)) {
          throw new Error('Invalid chat ID');
        }

        const num1 = Math.floor(Math.random() * 10);
        const num2 = Math.floor(Math.random() * 10);
        const operation = Math.random() > 0.5 ? '+' : '-';
        const correctResult = operation === '+' ? num1 + num2 : num1 - num2;

        const options = new Set([correctResult]);
        while (options.size < 4) {
          const wrongResult = correctResult + Math.floor(Math.random() * 5) - 2;
          if (wrongResult !== correctResult) options.add(wrongResult);
        }
        const optionArray = Array.from(options).sort(() => Math.random() - 0.5);

        const buttons = optionArray.map(option => ({
          text: `(${option})`,
          callback_data: `verify_${chatId}_${option}_${option === correctResult ? 'correct' : 'wrong'}`
        }));

        const question = `请计算：${num1} ${operation} ${num2} = ?（点击下方按钮完成验证）`;
        const nowSeconds = Math.floor(Date.now() / 1000);
        const codeExpiry = nowSeconds + 300;

        let userState = userStateCache.get(chatId);
        if (userState === undefined) {
          userState = { verification_code: correctResult.toString(), code_expiry: codeExpiry, last_verification_message_id: null, is_verifying: true };
        } else {
          userState.verification_code = correctResult.toString();
          userState.code_expiry = codeExpiry;
          userState.last_verification_message_id = null;
          userState.is_verifying = true;
        }
        userStateCache.set(chatId, userState);

        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: question,
            reply_markup: { inline_keyboard: [buttons] }
          })
        });
        const data = await response.json();
        if (data.ok) {
          userState.last_verification_message_id = data.result.message_id.toString();
          userStateCache.set(chatId, userState);
          await env.D1.prepare('UPDATE user_states SET verification_code = ?, code_expiry = ?, last_verification_message_id = ?, is_verifying = ? WHERE chat_id = ?')
            .bind(correctResult.toString(), codeExpiry, data.result.message_id.toString(), true, chatId)
            .run();
        } else {
          throw new Error(`Telegram API 返回错误: ${data.description || '未知错误'}`);
        }
      } catch (error) {
        console.error(`发送验证码失败: ${error.message}`);
        throw error;
      }
    }

    async function checkIfAdmin(userId) {
      try {
        if (!SecurityValidator.isValidUserId(userId)) {
          return false;
        }

        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/getChatMember`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: GROUP_ID,
            user_id: userId
          })
        });
        const data = await response.json();
        return data.ok && (data.result.status === 'administrator' || data.result.status === 'creator');
      } catch (error) {
        console.error('Check admin error:', error.message);
        return false;
      }
    }

    async function getUserInfo(chatId) {
      try {
        if (!SecurityValidator.isValidChatId(chatId)) {
          return null;
        }

        let userInfo = userInfoCache.get(chatId);
        if (userInfo !== undefined) {
          return userInfo;
        }

        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/getChat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ chat_id: chatId })
        });
        const data = await response.json();
        if (!data.ok) {
          userInfo = {
            id: chatId,
            username: `User_${chatId}`,
            nickname: `User_${chatId}`
          };
        } else {
          const result = data.result;
          const nickname = result.first_name
            ? `${result.first_name}${result.last_name ? ` ${result.last_name}` : ''}`.trim()
            : result.username || `User_${chatId}`;
          userInfo = {
            id: result.id || chatId,
            username: SecurityValidator.sanitizeText(result.username || `User_${chatId}`, 50),
            nickname: SecurityValidator.sanitizeText(nickname, 50)
          };
        }

        userInfoCache.set(chatId, userInfo);
        return userInfo;
      } catch (error) {
        console.error('Get user info error:', error.message);
        return {
          id: chatId,
          username: `User_${chatId}`,
          nickname: `User_${chatId}`
        };
      }
    }

    async function getExistingTopicId(chatId) {
      try {
        if (!SecurityValidator.isValidChatId(chatId)) {
          return null;
        }

        let topicId = topicIdCache.get(chatId);
        if (topicId !== undefined) {
          return topicId;
        }

        const result = await env.D1.prepare('SELECT topic_id FROM chat_topic_mappings WHERE chat_id = ?')
          .bind(chatId)
          .first();
        topicId = result?.topic_id || null;
        if (topicId) {
          topicIdCache.set(chatId, topicId);
        }
        return topicId;
      } catch (error) {
        console.error('Get existing topic ID error:', error.message);
        return null;
      }
    }

    async function createForumTopic(topicName, userName, nickname, userId) {
      try {
        // 安全增强：验证参数
        if (!topicName || !userName || !nickname) {
          throw new Error('Invalid topic parameters');
        }

        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/createForumTopic`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            chat_id: GROUP_ID, 
            name: SecurityValidator.sanitizeText(nickname, 100) 
          })
        });
        const data = await response.json();
        if (!data.ok) throw new Error(`Failed to create forum topic: ${data.description}`);
        const topicId = data.result.message_thread_id;

        const now = new Date();
        const formattedTime = now.toISOString().replace('T', ' ').substring(0, 19);
        const notificationContent = await getNotificationContent();
        const pinnedMessage = `昵称: ${SecurityValidator.sanitizeText(nickname, 100)}\n用户名: @${SecurityValidator.sanitizeText(userName, 50)}\nUserID: ${SecurityValidator.sanitizeText(userId.toString(), 20)}\n发起时间: ${formattedTime}\n\n${notificationContent}`;
        const messageResponse = await sendMessageToTopic(topicId, pinnedMessage);
        const messageId = messageResponse.result.message_id;
        await pinMessage(topicId, messageId);

        return topicId;
      } catch (error) {
        console.error('Create forum topic error:', error.message);
        throw error;
      }
    }

    async function saveTopicId(chatId, topicId) {
      try {
        if (!SecurityValidator.isValidChatId(chatId) || !SecurityValidator.isValidTopicId(topicId)) {
          throw new Error('Invalid topic ID or chat ID');
        }

        await env.D1.prepare('INSERT OR REPLACE INTO chat_topic_mappings (chat_id, topic_id) VALUES (?, ?)')
          .bind(chatId, topicId)
          .run();
        topicIdCache.set(chatId, topicId);
      } catch (error) {
        console.error('Save topic ID error:', error.message);
        throw error;
      }
    }

    async function getPrivateChatId(topicId) {
      try {
        if (!SecurityValidator.isValidTopicId(topicId)) {
          return null;
        }

        for (const [chatId, tid] of topicIdCache.cache) if (tid === topicId && SecurityValidator.isValidChatId(chatId)) return chatId;
        const mapping = await env.D1.prepare('SELECT chat_id FROM chat_topic_mappings WHERE topic_id = ?')
          .bind(topicId)
          .first();
        return mapping?.chat_id || null;
      } catch (error) {
        console.error('Get private chat ID error:', error.message);
        return null;
      }
    }

    async function sendMessageToTopic(topicId, text) {
      try {
        if (!SecurityValidator.isValidTopicId(topicId)) {
          throw new Error('Invalid topic ID');
        }

        const sanitizedText = SecurityValidator.sanitizeText(text);
        if (!sanitizedText) {
          throw new Error('Message text is empty or invalid');
        }

        const requestBody = {
          chat_id: GROUP_ID,
          text: sanitizedText,
          message_thread_id: topicId
        };
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        });
        const data = await response.json();
        if (!data.ok) {
          throw new Error(`Failed to send message to topic ${topicId}: ${data.description}`);
        }
        return data;
      } catch (error) {
        console.error('Send message to topic error:', error.message);
        throw error;
      }
    }

    async function copyMessageToTopic(topicId, message) {
      try {
        if (!SecurityValidator.isValidTopicId(topicId)) {
          throw new Error('Invalid topic ID');
        }

        const requestBody = {
          chat_id: GROUP_ID,
          from_chat_id: message.chat.id,
          message_id: message.message_id,
          message_thread_id: topicId,
          disable_notification: true
        };
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/copyMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        });
        const data = await response.json();
        if (!data.ok) {
          throw new Error(`Failed to copy message to topic ${topicId}: ${data.description}`);
        }
      } catch (error) {
        console.error('Copy message to topic error:', error.message);
        throw error;
      }
    }

    async function pinMessage(topicId, messageId) {
      try {
        if (!SecurityValidator.isValidTopicId(topicId) || !SecurityValidator.isValidMessageId(messageId)) {
          throw new Error('Invalid topic ID or message ID');
        }

        const requestBody = {
          chat_id: GROUP_ID,
          message_id: messageId,
          message_thread_id: topicId
        };
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/pinChatMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        });
        const data = await response.json();
        if (!data.ok) {
          throw new Error(`Failed to pin message: ${data.description}`);
        }
      } catch (error) {
        console.error('Pin message error:', error.message);
        throw error;
      }
    }

    async function forwardMessageToPrivateChat(privateChatId, message) {
      try {
        if (!SecurityValidator.isValidChatId(privateChatId)) {
          throw new Error('Invalid private chat ID');
        }

        const requestBody = {
          chat_id: privateChatId,
          from_chat_id: message.chat.id,
          message_id: message.message_id,
          disable_notification: true
        };
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/copyMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        });
        const data = await response.json();
        if (!data.ok) {
          throw new Error(`Failed to forward message to private chat: ${data.description}`);
        }
      } catch (error) {
        console.error('Forward message to private chat error:', error.message);
        throw error;
      }
    }

    async function sendMessageToUser(chatId, text) {
      try {
        if (!SecurityValidator.isValidChatId(chatId)) {
          throw new Error('Invalid chat ID');
        }

        const sanitizedText = SecurityValidator.sanitizeText(text);
        if (!sanitizedText) {
          throw new Error('Invalid message text');
        }

        const requestBody = { 
          chat_id: chatId, 
          text: sanitizedText 
        };
        const response = await fetchWithRetry(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(requestBody)
        });
        const data = await response.json();
        if (!data.ok) {
          throw new Error(`Failed to send message to user: ${data.description}`);
        }
      } catch (error) {
        console.error('Send message to user error:', error.message);
        throw error;
      }
    }

    async function fetchWithRetry(url, options, retries = 3, backoff = 1000) {
      for (let i = 0; i < retries; i++) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);
          
          // 安全增强：验证URL格式
          if (!url.startsWith('https://api.telegram.org/')) {
            throw new Error('Invalid URL');
          }
          
          const response = await fetch(url, { ...options, signal: controller.signal });
          clearTimeout(timeoutId);

          if (response.ok) {
            return response;
          }
          if (response.status === 429) {
            const retryAfter = response.headers.get('Retry-After') || 5;
            const delay = parseInt(retryAfter) * 1000;
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
          throw new Error(`Request failed with status ${response.status}: ${await response.text()}`);
        } catch (error) {
          if (i === retries - 1) throw error;
          await new Promise(resolve => setTimeout(resolve, backoff * Math.pow(2, i)));
        }
      }
      throw new Error(`Failed to fetch ${url} after ${retries} retries`);
    }

    async function registerWebhook(request) {
      try {
        const webhookUrl = `${new URL(request.url).origin}/webhook`;
        
        // 安全增强：验证URL
        if (!webhookUrl.startsWith('https://') || webhookUrl.length > 200) {
          return new Response('Invalid webhook URL', { status: 400 });
        }
        
        const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: webhookUrl })
        }).then(r => r.json());
        return new Response(response.ok ? 'Webhook set successfully' : JSON.stringify(response, null, 2));
      } catch (error) {
        console.error('Register webhook error:', error.message);
        return new Response('Webhook registration failed', { status: 500 });
      }
    }

    async function unRegisterWebhook() {
      try {
        const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: '' })
        }).then(r => r.json());
        return new Response(response.ok ? 'Webhook removed' : JSON.stringify(response, null, 2));
      } catch (error) {
        console.error('Unregister webhook error:', error.message);
        return new Response('Webhook removal failed', { status: 500 });
      }
    }

    try {
      return await handleRequest(request);
    } catch (error) {
      console.error('Main request handling error:', error.message);
      return new Response('Internal Server Error', { status: 500 });
    }
  }
};